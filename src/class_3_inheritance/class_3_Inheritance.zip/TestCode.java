package class_3_Inheritance;

public class TestCode {
    public static void main(String[] args) {
        AlarmManagement am = new AlarmManagement();
        am.addAlarmFromView();
        am.displayAlarmView();

        AlarmView av = new AlarmView();
        String[] fields = av.userCreateAnAlarm();
        for(String s:fields){
            System.out.print(s+" ");
        }
        System.out.println();
        int index = av.getAlarmIndex();
        System.out.println(index);
        av.displayAlarm("AlarmView tested");
    }
}
